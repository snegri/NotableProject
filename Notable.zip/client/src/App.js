//import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';
//import Set from 'collections/set'


class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      physicians: [],
      shownSchedule: [],
      tableShow: false,
    }
    this.showSchedule = this.showSchedule.bind(this)
  }

  componentDidMount() {
    this.fetchNames()
      .then(res => {
        this.setState({ physicians: res });
      })
      .catch(err => console.log(err));
  }

  fetchNames = async () => {
    const response = await fetch('/schedule/names');
    const body = await response.json();
    
    if (response.status !== 200) {
      throw Error(body.message) 
    }
    return body;
  };

  fetchSchedules = async (name) => {
    name = name.replace(/\s/g, '');
    const response = await fetch(`/physicians/${name}`);
    const body = await response.json();
    
    if (response.status !== 200) {
      throw Error(body.message) 
    }
    return body;
  };

  showSchedule(data) {
    this.fetchSchedules(data)
      .then(res => {
        this.setState({ shownSchedule: res.appointments });
        this.setState({ tableShow: true })
      })
      .catch(err => console.log(err));
    
  }

  renderButton(data) {
    return (
      <button className="button" onClick={() => {this.showSchedule(data)}}>
        {data}
      </button>
    )
  }

  renderTable(physician) {
    const header = ['Name', 'Time', 'Type']
    if (physician) {
      return (
        <table>
            <thead>
              <tr>{header.map((h, i) => <th key={i}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {Object.keys(physician).map((k, i) => {
                console.log(physician);
                let data = physician[k];
                return (
                  <tr key={i}>
                    <td>{data.name}</td>
                    <td>{data.time}</td>
                    <td>{data.kind}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )
    } else{
      <div>
        'No Data for this Physician...try reloading the page'
      </div>
    }
    
  }

  render() {
    const listItems = this.state.physicians.map((d) => {return this.renderButton(d)});

    return (
      <div class='btn-group'>
        { listItems }
        { this.state.tableShow && (<div> { this.renderTable(this.state.shownSchedule) }</div>)}
     </div>
    )
  }
}

export default App;
